
extern int DC_LoadVMU(char* filetoload, char* RAM);
extern int DC_SaveVMU(char* filetosave, char* namevmu_save, char* description);
