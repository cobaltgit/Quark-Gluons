#ifndef __LOGO
#define __LOGO

extern void logo_main( void );

#endif
