#ifndef REFRESH_H
#define REFRESH_H

#include <SDL.h>
#if defined(SCALING) || defined(OPENGL_SCALING)
	extern void RefreshScreen(SDL_Surface* tmp);
	extern SDL_Surface* real_screen;
#elif defined(TRIMUISMART)
#include "TMSr90.h"
	#define RefreshScreen TMS_Flip
#else
	#define RefreshScreen SDL_Flip
#endif
#endif
