#ifndef EXTERN_H
#define EXTERN_H

#include <stdint.h>
#include "define.h"

extern SDL_Surface *g_screen;
extern int g_scene;

extern Sint32 gameflag[GAMEFLAG_SIZE];
extern Sint32 gameflag2[GAMEFLAG_SIZE];

#endif
