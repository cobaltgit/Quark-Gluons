#include <stdio.h>
#include <stdlib.h>

#include <SDL.h>
#include "define.h"

SDL_Surface *g_screen;
Sint32 g_scene;
Sint32 gameflag[GAMEFLAG_SIZE];
Sint32 gameflag2[GAMEFLAG_SIZE];
