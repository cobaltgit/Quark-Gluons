#ifndef __OPTION
#define __OPTION

extern void option_main( void );

#endif
