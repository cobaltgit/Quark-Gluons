#ifndef __SCENEMANAGER
#define __SCENEMANAGER

extern void scenemanager( void );

#endif
