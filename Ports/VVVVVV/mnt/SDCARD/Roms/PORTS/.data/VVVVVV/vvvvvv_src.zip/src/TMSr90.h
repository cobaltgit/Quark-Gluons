//
//	Dealing with TrimuiSmart's 90-degree rotated LCD
//		alternative to slower SDL_VIDEO_FBCON_ROTATION
//
#ifndef __TMSR90_H__
#define __TMSR90_H__

#include <stdint.h>
#include <SDL/SDL.h>

#ifdef __cplusplus
extern "C" {
#endif

//
//	SetVideoMode function to use instead of SDL_SetVideoMode
//		must be width:320 height:240 bpp:16 to be valid
//
//	flags affect Flip operation:
//		SWSURFACE		Flip immediately without VSYNC wait
//					- Fastest, but some tearing occurs
//		HWSURFACE		Flip processing is left to thread and returns immediately
//					Thread waits VSYNC and then Flip
//					If called again during actual processing, overwrite next screen displayed
//					- Fast, but frame skipping occurs
//		HWSURFACE|DOUBLEBUF	Flip processing is left to thread as above, and returns immediately if not in process
//					If called again during actual processing, waits until processing is done (blocking)
//					- Standard speed and display all frames
//		SWSURFACE|DOUBLEBUF	Flip after waiting VSYNC on the spot, without threading
//					- Stable but slowest, for cases where you want to wait until VSYNC to ensure speed adjustment
//
//	flags can be changed by executing TMS_SetVideoMode(320,240,16,flags); again at any time
//
SDL_Surface* TMS_SetVideoMode(int width, int height, int bpp, uint32_t flags);

//
//	Flip function to use instead of SDL_Flip
//		(UpdateRect is not supported)
//
int TMS_Flip(SDL_Surface *screen);

//
//	Cleanup used resources, for use before SDL_Quit
//
void TMS_Quit(void);

//
//	GetVideoSurface function to use instead of SDL_GetVideoSurface
//
SDL_Surface *TMS_GetVideoSurface(void);

//
//	GetVideoInfo function to use instead of SDL_GetVideoInfo
//
SDL_VideoInfo *TMS_GetVideoInfo(void);

//
//	VideoModeOK function to use instead of SDL_VideoModeOK
//
int TMS_VideoModeOK(int width, int height, int bpp, Uint32 flags);

#ifdef __cplusplus
}
#endif
#endif
