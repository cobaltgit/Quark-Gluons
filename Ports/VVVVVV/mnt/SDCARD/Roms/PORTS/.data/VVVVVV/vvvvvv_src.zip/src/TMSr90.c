//
//	Dealing with TrimuiSmart's 90-degree rotated LCD
//		alternative to slower SDL_VIDEO_FBCON_ROTATION
//
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <linux/fb.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <SDL/SDL.h>

//
//	global variables
//
int		fb0_fd = 0;
void*		fb0_map = 0;
pthread_t	flip_pt = 0;
pthread_mutex_t	flip_mx;
pthread_cond_t	flip_req;
pthread_cond_t	flip_start;
uint32_t	hws;
uint32_t	dbb;
SDL_Surface	*shadow = 0;
void*		flipbuffer;
struct fb_var_screeninfo vinfo;

//
//	320x240 -> 240x320 16bpp rotate90 CCW read/write32bit
//		takes about 0.420ms
//
void rotate320x240_rw32(void* __restrict src, void* __restrict dst) {
	uint32_t	*s, *d, pix1, pix2;
	int		x, y;

	s = (uint32_t*)src + 159;
	d = (uint32_t*)dst;
	for (x=160; x>0; x--, s -= 160*240+1, d += 120) {
		for (y=120; y>0; y--, s += 320, d++) {
			pix1 = s[0];					// read AB
			pix2 = s[160];					// read CD
			d[0] = (pix1>>16) | (pix2 & 0xFFFF0000);	// write BD
			d[120] = (pix1 & 0xFFFF) | (pix2<<16);		// write AC
		}
	}
}

//
//	read clock (for debug)
//
uint64_t TSclock(void) {
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (ts.tv_nsec) + (ts.tv_sec * 1000000000);
}
uint64_t now;
void	startclock(void) { now = TSclock(); }
void	printclock(void) { fprintf(stderr, "elapsed: %f ms\n",(double)(TSclock() - now)/1000000 ); }
void	printinterval(void) {
	static uint64_t interval;
	now = TSclock();
	if (interval) fprintf(stderr, "interval: %f ms\n",(double)(interval - now)/1000000);
	interval = now;
}

//
//	Actual Flip thread for HWSURFACE
//
static void* FlipThread(void* param) {
	pthread_mutex_lock(&flip_mx);
	pthread_cond_signal(&flip_start);
	while(1) {
		pthread_cond_wait(&flip_req, &flip_mx);

		// VSYNC wait
		int	dmy;
		if (!dbb) {
			// If non DOUBLEBUF, accept TMS_Flip while waiting
			pthread_mutex_unlock(&flip_mx);
			ioctl(fb0_fd, FBIO_WAITFORVSYNC, &dmy);
			pthread_mutex_lock(&flip_mx);
		} else {
			ioctl(fb0_fd, FBIO_WAITFORVSYNC, &dmy);
		}

		// blit and flip
		vinfo.yoffset ^= 320;
		rotate320x240_rw32(flipbuffer, fb0_map + vinfo.yoffset*240*2);
		ioctl(fb0_fd, FBIOPAN_DISPLAY, &vinfo);
	}
	pthread_mutex_unlock(&flip_mx);
	return 0;
}

//
//	Flip function to use instead of SDL_Flip
//
int TMS_Flip(SDL_Surface *screen) {
	if (!fb0_fd) return SDL_Flip(screen);
	if (hws) {
		// for HWSURFACE, write to flipbuffer and send flip request to Flipthread
		pthread_mutex_lock(&flip_mx);
		memcpy(flipbuffer, screen->pixels, 240*320*2);	// takes about 0.300ms
		pthread_cond_signal(&flip_req);
		pthread_mutex_unlock(&flip_mx);
		// for DOUBLEBUF, pass control to Flipthread once to let it recieve request
		if (dbb) usleep(0);	// takes about 0.080ms
	} else {
		// for SWSURFACE, write to backbuffer and Flip immediately
		if (dbb) { int dmy; ioctl(fb0_fd, FBIO_WAITFORVSYNC, &dmy); } // VSYNC wait when DOUBLEBUF
		vinfo.yoffset ^= 320;
		rotate320x240_rw32(screen->pixels, fb0_map + vinfo.yoffset*240*2);
		ioctl(fb0_fd, FBIOPAN_DISPLAY, &vinfo);
	}
	return 0;
}

//
//	SetVideoMode function to use instead of SDL_SetVideoMode
//		must be w:320 h:240 bpp:16 to be valid
//
SDL_Surface* TMS_SetVideoMode(int width, int height, int bpp, uint32_t flags) {
	if ((width!=320)||(height!=240)||(bpp!=16)) return SDL_SetVideoMode(width, height, bpp, flags);
	if (!fb0_fd) {
		// init videosurface (unused, just in case)
		SDL_SetVideoMode(240, 320, 16, SDL_HWSURFACE);
		// prepare for handling framebuffer
		fb0_fd = open("/dev/fb0", O_RDWR);
		fb0_map = mmap(0, 240*320*2*2, PROT_WRITE, MAP_SHARED, fb0_fd, 0);
		ioctl(fb0_fd, FBIOGET_VSCREENINFO, &vinfo);
		vinfo.yoffset = 0;
		ioctl(fb0_fd, FBIOPAN_DISPLAY, &vinfo);
		memset(fb0_map, 0, 240*320*2*2);
		// allocate flipbuffer for HWSURFACE
		flipbuffer = malloc(240*320*2);
		// create Flip thread and wait until thread start
		flip_mx = (pthread_mutex_t)PTHREAD_MUTEX_INITIALIZER;
		flip_req = (pthread_cond_t)PTHREAD_COND_INITIALIZER;
		flip_start = (pthread_cond_t)PTHREAD_COND_INITIALIZER;
		pthread_mutex_lock(&flip_mx);
		pthread_create(&flip_pt, NULL, FlipThread, NULL);
		pthread_cond_wait(&flip_start, &flip_mx);
		pthread_mutex_unlock(&flip_mx);
	}
	// save HWSURFACE/DOUBLEBUF flag
	hws = (flags & SDL_HWSURFACE);
	dbb = (flags & SDL_DOUBLEBUF);
	// return 320x240x16bpp shadowsurface
	if (!shadow) shadow = SDL_CreateRGBSurface(0, 320, 240, 16, 0xF800, 0x07E0, 0x001F, 0);
	return shadow;
}

//
//	Cleanup used resources
//		for use before SDL_Quit
//
void TMS_Quit(void) {
	if (fb0_fd) {
		pthread_cancel(flip_pt);
		pthread_join(flip_pt, NULL);
		SDL_FreeSurface(shadow);
		shadow = 0;
		free(flipbuffer);
		memset(fb0_map, 0, 240*320*2*2);
		munmap(fb0_map, 240*320*2*2);
		fb0_map = 0;
		close(fb0_fd);
		fb0_fd = 0;
	}
}

//
//	GetVideoSurface function to use instead of SDL_GetVideoSurface
//
SDL_Surface *TMS_GetVideoSurface(void) {
	if (!shadow) return SDL_GetVideoSurface();
	return shadow;
}

//
//	GetVideoInfo function to use instead of SDL_GetVideoInfo
//
SDL_VideoInfo ret;
SDL_VideoInfo *TMS_GetVideoInfo(void) {
	SDL_VideoInfo const *vi = SDL_GetVideoInfo();
	memcpy(&ret, vi, sizeof(SDL_VideoInfo));
	ret.current_w = 320;
	ret.current_h = 240;
	return &ret;
}

//
//	VideoModeOK function to use instead of SDL_VideoModeOK
//
int TMS_VideoModeOK(int width, int height, int bpp, Uint32 flags) {
	if ((width!=320)||(height!=240)) return SDL_VideoModeOK(width, height, bpp, flags);
	return 16;
}
