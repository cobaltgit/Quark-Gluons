-- How to build --

1. Download sources from this commit. https://github.com/FunKey-Project/sm64-port/tree/561dd7c8d3cec30e856fb9bdd803f32541ca7f33
2. Refer to the Dockerfile and install tools specified to be installed in it that are not yet installed. (especially bsdmainutils and python3)
3. Overwrite Makefile and src directory in this zip to downloaded sources. (modify CROSS_COMPILE at the beginning of the Makefile if necessary)
4. Prepare SM64 US ROM with the name "baserom.us.z64" and place it in the same location as the Makefile. (SHA1:9bef1128717f958171a4afac3ed78ee2bb4e86ce)
5. Make.
6. Copy /build/us_pc/sm64.us.f3dex2e to /Apps/sm64.
