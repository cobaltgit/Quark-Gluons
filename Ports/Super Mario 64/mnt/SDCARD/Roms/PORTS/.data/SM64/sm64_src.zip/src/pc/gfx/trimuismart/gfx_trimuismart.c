#include <SDL/SDL.h>
#include <time.h>

#include "../../common.h"
#include "../../configfile.h"
#include "../gfx_window_manager_api.h"
#include "../gfx_screen_config.h"
#include "TMSr90.c"

#if defined(VERSION_EU)
#define FRAMERATE 25
#else
#define FRAMERATE 30
#endif

#define GFX_API_NAME "SDL1.2 - Software"
#include "../gfx_soft.h"
SDL_Surface *sdl_screen = NULL;
SDL_Surface *scaled = NULL;
//uint16_t *gfx_output;

static int inverted_scancode_table[512];
static unsigned int window_width = DESIRED_SCREEN_WIDTH;
static unsigned int window_height = DESIRED_SCREEN_HEIGHT;
static void (*on_fullscreen_changed_callback)(bool is_now_fullscreen);
static bool (*on_key_down_callback)(int scancode);
static bool (*on_key_up_callback)(int scancode);
static void (*on_all_keys_up_callback)(void);

// time between consequtive game frames
const int frame_time = 1000000 / FRAMERATE;

// fps stats tracking
static int f_frames = 0;
static double f_time = 0.0;

const SDLKey windows_scancode_table[] =
{
/*	0		1		2			3			4		5		6		7 */
/*	8		9		A			B			C		D		E		F */
	SDLK_UNKNOWN,	SDLK_ESCAPE,	SDLK_1,			SDLK_2,			SDLK_3,		SDLK_4,		SDLK_5,		SDLK_6,		/* 0 */
	SDLK_7,		SDLK_8,		SDLK_9,			SDLK_0,			SDLK_MINUS,	SDLK_EQUALS,	SDLK_BACKSPACE,	SDLK_TAB,	/* 0 */

	SDLK_q,		SDLK_w,		SDLK_e,			SDLK_r,			SDLK_t,		SDLK_y,		SDLK_u,		SDLK_i,		/* 1 */
	SDLK_o,		SDLK_p,		SDLK_LEFTBRACKET,	SDLK_RIGHTBRACKET,	SDLK_RETURN,	SDLK_LCTRL,	SDLK_a,		SDLK_s,		/* 1 */

	SDLK_d,		SDLK_f,		SDLK_g,			SDLK_h,			SDLK_j,		SDLK_k,		SDLK_l,		SDLK_SEMICOLON,	/* 2 */
	SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_LSHIFT,		SDLK_BACKSLASH,		SDLK_z,		SDLK_x,		SDLK_c,		SDLK_v,		/* 2 */

	SDLK_b,		SDLK_n,		SDLK_m,			SDLK_COMMA,		SDLK_PERIOD,	SDLK_SLASH,	SDLK_RSHIFT,	SDLK_PRINT,	/* 3 */
	SDLK_LALT,	SDLK_SPACE,	SDLK_CAPSLOCK,		SDLK_F1,		SDLK_F2,	SDLK_F3,	SDLK_F4,	SDLK_F5,	/* 3 */

	SDLK_F6,	SDLK_F7,	SDLK_F8,		SDLK_F9,		SDLK_F10,	SDLK_NUMLOCK,	SDLK_SCROLLOCK,	SDLK_HOME,	/* 4 */
	SDLK_UP,	SDLK_PAGEUP,	SDLK_KP_MINUS,		SDLK_LEFT,		SDLK_KP5,	SDLK_RIGHT,	SDLK_KP_PLUS,	SDLK_END,	/* 4 */

	SDLK_DOWN,	SDLK_PAGEDOWN,	SDLK_INSERT,		SDLK_DELETE,		SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_BACKSLASH,	SDLK_F11,	/* 5 */
	SDLK_F12,	SDLK_PAUSE,	SDLK_UNKNOWN,		SDLK_UNKNOWN,		SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,	/* 5 */

	SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,		SDLK_UNKNOWN,		SDLK_F13,	SDLK_F14,	SDLK_F15,	SDLK_UNKNOWN,	/* 6 */
	SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,		SDLK_UNKNOWN,		SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,	/* 6 */

	SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,		SDLK_UNKNOWN,		SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,	/* 7 */
	SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,		SDLK_UNKNOWN,		SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN,	SDLK_UNKNOWN	/* 7 */
};

const SDLKey scancode_rmapping_extended[][2] = {
    {SDLK_KP_ENTER, SDLK_RETURN},
    {SDLK_RALT, SDLK_LALT},
    {SDLK_RCTRL, SDLK_LCTRL},
    {SDLK_KP_DIVIDE, SDLK_SLASH},
    //{SDLK_KP_PLUS, SDLK_CAPSLOCK}
};

const SDLKey scancode_rmapping_nonextended[][2] = {
    {SDLK_KP7, SDLK_HOME},
    {SDLK_KP8, SDLK_UP},
    {SDLK_KP9, SDLK_PAGEUP},
    {SDLK_KP4, SDLK_LEFT},
    {SDLK_KP6, SDLK_RIGHT},
    {SDLK_KP1, SDLK_END},
    {SDLK_KP2, SDLK_DOWN},
    {SDLK_KP3, SDLK_PAGEDOWN},
    {SDLK_KP0, SDLK_INSERT},
    {SDLK_KP_PERIOD, SDLK_DELETE},
    {SDLK_KP_MULTIPLY, SDLK_PRINT},
    {SDLK_UP, SDLK_UP},
    {SDLK_LEFT, SDLK_LEFT},
    {SDLK_RIGHT, SDLK_RIGHT},
    {SDLK_DOWN, SDLK_DOWN},
};

static void set_fullscreen(bool on, bool call_callback) { }

static void gfx_sdl_init(const char *game_name, bool start_in_fullscreen) {
    SDL_Init(SDL_INIT_VIDEO);

    char title[512];
    sprintf(title, "%s (%s)", game_name, GFX_API_NAME);

    window_width = configScreenWidth;
    window_height = configScreenHeight;

    sdl_screen = TMS_SetVideoMode(320, 240, 16, SDL_HWSURFACE);
    if ((window_width != 320)||(window_width != 240)) {
	scaled = sdl_screen;
        sdl_screen = SDL_CreateRGBSurface(0, window_width, window_height, 16, 0xF800, 0x07E0, 0x001F, 0);
    }
    gfx_output = sdl_screen->pixels;

    f_time = SDL_GetTicks();

    for (size_t i = 0; i < sizeof(windows_scancode_table) / sizeof(SDLKey); i++) {
        inverted_scancode_table[windows_scancode_table[i]] = i;
    }

    for (size_t i = 0; i < sizeof(scancode_rmapping_extended) / sizeof(scancode_rmapping_extended[0]); i++) {
        inverted_scancode_table[scancode_rmapping_extended[i][0]] = inverted_scancode_table[scancode_rmapping_extended[i][1]] + 0x100;
    }

    for (size_t i = 0; i < sizeof(scancode_rmapping_nonextended) / sizeof(scancode_rmapping_nonextended[0]); i++) {
        inverted_scancode_table[scancode_rmapping_nonextended[i][0]] = inverted_scancode_table[scancode_rmapping_nonextended[i][1]];
        inverted_scancode_table[scancode_rmapping_nonextended[i][1]] += 0x100;
    }
}

static void gfx_sdl_set_fullscreen_changed_callback(void (*on_fullscreen_changed)(bool is_now_fullscreen)) {
    on_fullscreen_changed_callback = on_fullscreen_changed;
}

static void gfx_sdl_set_fullscreen(bool enable) {
    set_fullscreen(enable, true);
}

static void gfx_sdl_set_keyboard_callbacks(bool (*on_key_down)(int scancode), bool (*on_key_up)(int scancode), void (*on_all_keys_up)(void)) {
    on_key_down_callback = on_key_down;
    on_key_up_callback = on_key_up;
    on_all_keys_up_callback = on_all_keys_up;
}

static void gfx_sdl_main_loop(void (*run_one_game_iter)(void)) {
    while (1) {
        run_one_game_iter();
    }
}

static void gfx_sdl_get_dimensions(uint32_t *width, uint32_t *height) {
    *width = configScreenWidth;
    *height = configScreenHeight;
}

static int translate_scancode(int scancode) {
    if (scancode < 512) {
        return inverted_scancode_table[scancode];
    } else {
        return 0;
    }
}

static void gfx_sdl_onkeydown(int scancode) {
    int key = translate_scancode(scancode);

    if (on_key_down_callback != NULL) {
        on_key_down_callback(key);
    }
}

static void gfx_sdl_onkeyup(int scancode) {
    int key = translate_scancode(scancode);
    if (on_key_up_callback != NULL) {
        on_key_up_callback(key);
    }
}

static void gfx_sdl_handle_events(void) {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        switch (event.type) {
            case SDL_KEYDOWN:
		if (event.key.keysym.sym == SDLK_ESCAPE) game_exit();
		gfx_sdl_onkeydown(event.key.keysym.sym);
		break;
            case SDL_KEYUP:
		gfx_sdl_onkeyup(event.key.keysym.sym);
		break;
            case SDL_QUIT:
		game_exit();
		break;
        }
    }
}

static bool gfx_sdl_start_frame(void) {
	static Uint64 last_time = 0;
	static Uint32 skip_frames = 0;
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	const Uint64 now = (ts.tv_nsec/1000) + (ts.tv_sec * 1000000);

	// get base timestamp on the first frame (might be different from 0)
	if (last_time == 0) last_time = now;
	int elapsed = now - last_time;
	if ((elapsed > 0)&&(elapsed < 0x80000)) {
		if (elapsed < frame_time) {
			usleep(frame_time - elapsed);
			skip_frames = 0;
			last_time += frame_time;
			return true;
		} else if (skip_frames++ < configFrameskip) {
			last_time += frame_time;
			return false;
		}
	}
	skip_frames = 0;
	last_time = now;
	return true;
}

/* Nearest neighbor scaler from miyoomini retroarch */
#define NN_SHIFT 16
static void scalenn_16(void* __restrict src, void* __restrict dst, uint32_t sw, uint32_t sh) {
   uint32_t dw = 320;
   uint32_t dh = 240;

   uint32_t x_step = (sw << NN_SHIFT) / dw + 1;
   uint32_t y_step = (sh << NN_SHIFT) / dh + 1;

   uint32_t in_stride  = sw;
   uint32_t out_stride = 320;

   uint16_t* in_ptr  = (uint16_t*)src;
   uint16_t* out_ptr = (uint16_t*)dst;

   uint32_t oy = 0;
   uint32_t y  = 0;

   /* Reading 16bits takes a little time,
      so try not to read as much as possible in the case of 16bpp */
   if (dh > sh) {
      if (dw > sw) {
         do {
            uint32_t col = dw;
            uint32_t ox  = 0;
            uint32_t x   = 0;

            uint16_t* optrtmp1 = out_ptr;

            uint16_t pix = in_ptr[0];
            do {
               uint32_t tx = x >> NN_SHIFT;
               if (tx != ox) {
                  pix = in_ptr[tx];
                  ox  = tx;
               }
               *(out_ptr++) = pix;
               x           += x_step;
            } while (--col);

            y += y_step;
            uint32_t ty = y >> NN_SHIFT;
            uint16_t* optrtmp2 = optrtmp1;
            for(; ty == oy; y += y_step, ty = y >> NN_SHIFT) {
               if (!--dh) return;
               optrtmp2 += out_stride;
               memcpy(optrtmp2, optrtmp1, dw << 1);
            }
            in_ptr += (ty - oy) * in_stride;
            out_ptr = optrtmp2 + out_stride;
            oy      = ty;
         } while (--dh);
      } else {
         do {
            uint32_t col = dw;
            uint32_t x   = 0;

            uint16_t* optrtmp1 = out_ptr;

            do {
               *(out_ptr++) = in_ptr[x >> NN_SHIFT];
               x           += x_step;
            } while (--col);

            y += y_step;
            uint32_t ty = y >> NN_SHIFT;
            uint16_t* optrtmp2 = optrtmp1;
            for(; ty == oy; y += y_step, ty = y >> NN_SHIFT) {
               if (!--dh) return;
               optrtmp2 += out_stride;
               memcpy(optrtmp2, optrtmp1, dw << 1);
            }
            in_ptr += (ty - oy) * in_stride;
            out_ptr = optrtmp2 + out_stride;
            oy      = ty;
         } while (--dh);
      }
   } else {
      if (dw > sw) {
         do {
            uint32_t col = dw;
            uint32_t ox  = 0;
            uint32_t x   = 0;

            uint16_t* optrtmp1 = out_ptr;

            uint16_t pix = in_ptr[0];
            do {
               uint32_t tx = x >> NN_SHIFT;
               if (tx != ox) {
                  pix = in_ptr[tx];
                  ox  = tx;
               }
               *(out_ptr++) = pix;
               x           += x_step;
            } while (--col);

            y += y_step;
            uint32_t ty = y >> NN_SHIFT;
            in_ptr += (ty - oy) * in_stride;
            out_ptr = optrtmp1 + out_stride;
            oy      = ty;
         } while (--dh);
      } else {
         do {
            uint32_t col = dw;
            uint32_t x   = 0;

            uint16_t* optrtmp1 = out_ptr;

            do {
               *(out_ptr++) = in_ptr[x >> NN_SHIFT];
               x           += x_step;
            } while (--col);

            y += y_step;
            uint32_t ty = y >> NN_SHIFT;
            in_ptr += (ty - oy) * in_stride;
            out_ptr = optrtmp1 + out_stride;
            oy      = ty;
         } while (--dh);
      }
   }
}

static void gfx_sdl_swap_buffers_begin(void) {
	if (!scaled) { TMS_Flip(sdl_screen); return; }
	scalenn_16(gfx_output, scaled->pixels, window_width, window_height);
	TMS_Flip(scaled);
	return;
}

static void gfx_sdl_swap_buffers_end(void) {
	f_frames++;
}

static double gfx_sdl_get_time(void) {
	return 0.0;
}

static void gfx_sdl_shutdown(void) {
    const double elapsed = (SDL_GetTicks() - f_time) / 1000.0;
    printf("\nstats\n");
    printf("frames    %010d\n", f_frames);
    printf("time      %010.4lf sec\n", elapsed);
    printf("frametime %010.8lf sec\n", elapsed / (double)f_frames);
    printf("framerate %010.5lf fps\n\n", (double)f_frames / elapsed);
    fflush(stdout);

    TMS_Quit();
    if (scaled) SDL_FreeSurface(sdl_screen);
    SDL_Quit();
}

struct GfxWindowManagerAPI gfx_sdl = {
    gfx_sdl_init,
    gfx_sdl_set_keyboard_callbacks,
    gfx_sdl_set_fullscreen_changed_callback,
    gfx_sdl_set_fullscreen,
    gfx_sdl_main_loop,
    gfx_sdl_get_dimensions,
    gfx_sdl_handle_events,
    gfx_sdl_start_frame,
    gfx_sdl_swap_buffers_begin,
    gfx_sdl_swap_buffers_end,
    gfx_sdl_get_time,
    gfx_sdl_shutdown,
};
