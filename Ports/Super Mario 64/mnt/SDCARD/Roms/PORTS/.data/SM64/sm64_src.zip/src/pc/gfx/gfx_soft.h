#ifndef GFX_SOFT_H
#define GFX_SOFT_H

#include "gfx_rendering_api.h"

// For some strange reasons, trying to use SDL to convert the surface
// on the Funkey results in a bus error and crash...

#if defined(RS97)
//#define CONVERT
//#define DIRECT_SDL
#define SDL_SURFACE
#elif defined(TRIMUISMART)
#define CONVERT
//#define DIRECT_SDL
#define SDL_SURFACE
#elif defined(MIYOOMINI)
#define NOREVERSE
//#define CONVERT
//#define DIRECT_SDL
#define SDL_SURFACE
#else
//#define CONVERT
#define DIRECT_SDL
#define SDL_SURFACE
#endif

extern struct GfxRenderingAPI gfx_soft_api;

#ifdef CONVERT
extern uint16_t *gfx_output;
#else
extern uint32_t *gfx_output;
#endif

#endif
